from django.contrib import admin
from django.contrib import admin
from .models import models, Personnel, Poste, Horaire
# Register your models here.

@admin.register(Poste) 
class AuteurAdmin(admin.ModelAdmin):
    list_display = ('as_poste','nom_poste','somme','heure_debut','heure_fin')
    list_filter = ['as_poste']
    
@admin.register(Horaire) 
class AuteurAdmin(admin.ModelAdmin):
    list_display = ('arrival_time','departure_time','personnel')

@admin.register(Personnel) 
class AuteurAdmin(admin.ModelAdmin):
    list_display = ('name','prenom','poste','email','gender')
    search_fields = ['name']




